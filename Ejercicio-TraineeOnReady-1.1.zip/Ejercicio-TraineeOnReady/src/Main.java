public class Main {

    final static Vehiculo[] vehiculos = new Vehiculo[4];


    public static void main(String[] args) {
	// write your code here
        insertarVehiculo(vehiculos);
        for (int i = 0; i<vehiculos.length;i++){
            System.out.println(vehiculos[i]);
        }
        System.out.println("===========================");
        ordenPrecio();
        System.out.println("Vehiculo mas caro: " + vehiculos[0].getMarca()+" "+vehiculos[0].getModelo());
        System.out.println("Vehiculo mas barato: " + vehiculos[3].getMarca()+" "+vehiculos[3].getModelo());
        filtroPorLetra();
        System.out.println("===========================");
        System.out.println("Vehiculos ordenados por precio de mayor a menor: ");
        for (int i = 0; i< vehiculos.length;i++)
            System.out.println(vehiculos[i].getMarca() + " " + vehiculos[i].getModelo());
    }

    public static void insertarVehiculo(Vehiculo[] vehiculos){
        vehiculos[0]=new Auto("Peugeot", "206", 4,200000.00);
        vehiculos[1]=new Moto("Honda","Titan",125,60000.00);
        vehiculos[2]=new Auto("Peugeot","208",5,250000.00);
        vehiculos[3]=new Moto("Yamaha","YBR",160,80500.50);
    }
    public static Vehiculo ordenPrecio(){
        Vehiculo veh = null;

        for(int i = 0; i<vehiculos.length-1;i++)
            for(int j = i; j<vehiculos.length;j++)
                if(vehiculos[i].getPrecio()<vehiculos[j].getPrecio()){
                    veh = vehiculos[i];
                    vehiculos[i] = vehiculos[j];
                    vehiculos[j] = veh;
                }
        return veh;
    }
    public static void filtroPorLetra(){

        String letra = "Y";
        System.out.println("Vehiculo que contiene en el modelo el caracter "+letra);
        for (int i = 0; i< vehiculos.length-1;i++)
            if(letra.charAt(0)==vehiculos[i].getModelo().charAt(0))
                System.out.println(vehiculos[i].getMarca()+" "+vehiculos[i].getModelo());

    }
}
